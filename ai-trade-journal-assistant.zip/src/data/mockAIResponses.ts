import { Trade, AIAnalysis } from '../types';

export const mockAIResponses: { [tradeId: string]: AIAnalysis } = {
  "trade-1": {
    tradeId: "trade-1",
    performanceSummary: "Excellent execution of a support retest trade on BTC. Entering with 10x leverage was a highly disciplined choice, giving you ample breathing room while holding a reasonable margin size. Waiting for structural confirmation on long-term daily support shows professional patience.",
    mistakesWarnings: [
      "None identified. This was a textbook trade executed exactly in line with robust chart rules."
    ],
    improvements: [
      "Consider trailing your stop-loss into profit after the first 50% target is hit to lock in risk-free gains.",
      "Explore partial take-profits to capture liquidity on high-velocity wicks."
    ],
    nextTradeSuggestion: "Continue searching for high-timeframe support test plays on major coins (BTC/ETH). Maintain low leverage under 15x. Avoid mid-range drift plays.",
    analyzedAt: "2026-04-25T14:35:00Z"
  },
  "trade-2": {
    tradeId: "trade-2",
    performanceSummary: "Solid short entry on the ETH 4H double top pattern. Your analysis was sound, but your manual exit prior to the take-profit target indicates a minor lack of confidence in your setup. With a 20x leverage ratio, minor retracements can induce early pullbacks.",
    mistakesWarnings: [
      "Manual exit cut your potential profit by approximately 15% due to short-term fear.",
      "20x leverage is relatively high for a 4H swing trade; this increased your sensitivity to normal minor noise."
    ],
    improvements: [
      "Let the trade structure play out. Trust your predefined limit orders.",
      "Reduce leverage to 10x on ETH swing setups to increase your mental comfort zone."
    ],
    nextTradeSuggestion: "Watch for secondary lower-high formations on ETH for a re-entry with lower leverage (10x). Keep stops strict above the double top peak.",
    analyzedAt: "2026-04-28T09:20:00Z"
  },
  "trade-3": {
    tradeId: "trade-3",
    performanceSummary: "A severe over-leveraged trade on SOL driven by social media hype (FOMO). Entering long at local peaks with 50x leverage and without a hard stop-loss is extremely dangerous. It resulted in a rapid liquidation of your entire 50 USDT margin within minutes.",
    mistakesWarnings: [
      "Extremely high leverage (50x) gave you a liquidation price only 2% away from entry.",
      "Emotional entry (FOMO) prompted by external chatter rather than technical confirmation.",
      "Absence of a stop loss order left you fully exposed to the immediate liquidation."
    ],
    improvements: [
      "Implement a strict rule: No trades entered based on social media trends.",
      "Limit custom leverages to a maximum of 10x-15x on altcoins.",
      "Never click place-order without entering Stop Loss variables first."
    ],
    nextTradeSuggestion: "Stay fully cash for 48 hours to reset your emotion. For your next play, select SOL or ETH on low leverage (3x-5x), entering only on clear key support wicks.",
    analyzedAt: "2026-05-02T18:50:00Z"
  },
  "trade-4": {
    tradeId: "trade-4",
    performanceSummary: "A high-risk 100x leverage gamble on DOGE seeking an speculative burst. Speculative trading of memecoins on max leverage relies purely on luck and inevitably leads to rapid capital depletion. A tiny 1% market move wiped out 80% of your position margin.",
    mistakesWarnings: [
      "Using 100x leverage turns trading into casino betting. System noise will liquidate you.",
      "Emotional state identified as 'Greedy' — trying to turn 100 USDT into 500 USDT in one click.",
      "Extremely bad placement of entry during a consolidation zone with zero structural breakout."
    ],
    improvements: [
      "Ban 100x leverage on your account immediately. Maximum leverage allowed should be 5x on altcoins.",
      "Focus on slow compounding (1-2% account growth per trade) rather than hunting overnight windfalls."
    ],
    nextTradeSuggestion: "Delete dog coins from your watchlist temporarily. Pick a high-cap asset like BTC, plot out the daily highs/lows, and execute a simple, low-leverage (2-5x) range trade.",
    analyzedAt: "2026-05-05T22:15:00Z"
  },
  "trade-5": {
    tradeId: "trade-5",
    performanceSummary: "While this trade ended in a highly profitable 200% return on PEPE, the underlying catalyst was 'Revenge Trading' and anger. It succeeded purely due to lucky market timing. Over the long run, emotional revenge trading on meme coins carries a 90%+ failure rate.",
    mistakesWarnings: [
      "Revenge trading to recoup losses is a toxic habit that leads to compounding account blowouts.",
      "Entering randomly without a strict technical trigger exposes you to severe downside risk."
    ],
    improvements: [
      "Acknowledge that this win was lucky, not skillful. Retain humility to avoid catastrophic losses on the next play.",
      "Create a mandatory cooling-off period of 4 hours after any losing trade before taking new positions."
    ],
    nextTradeSuggestion: "Withdraw the winnings of this trade immediately. Start fresh with a small size, restricting your next trade to a Calm state entry on BTC or ETH.",
    analyzedAt: "2026-05-08T11:25:00Z"
  },
  "trade-6": {
    tradeId: "trade-6",
    performanceSummary: "A fearful play on BTC where micro-volatility caused you to panic-close your short prematurely. Over-monitoring the 1-minute chart often distorts structural trends, inducing fear on normal healthy retracements.",
    mistakesWarnings: [
      "Closed the position at a bad entry price due to panic, failing to let the structural pattern complete.",
      "20x leverage magnified intermediate floating losses, triggering fear response."
    ],
    improvements: [
      "After placing a trade with preset SL and TP, close your terminal and check back hourly.",
      "Reduce leverage to 10x which divides your emotional pressure by half."
    ],
    nextTradeSuggestion: "Focus on higher-timeframe structures. Set alerts near your TP and SL levels on the TradingView platform and avoid watching live ticks in the exchange interface.",
    analyzedAt: "2026-05-10T08:05:00Z"
  }
};

export function generateSmartMockResponse(trade: Trade): AIAnalysis {
  const isLoss = trade.pnlUsdt < 0;
  const leverageVal = trade.leverage;
  const coin = trade.coinName.toUpperCase();
  const emotion = trade.emotionalState;
  
  let summary = "";
  const mistakes: string[] = [];
  const improvements: string[] = [];
  let nextTrade = "";

  // 1. Performance Summary
  if (!isLoss) {
    if (emotion === 'Calm' || emotion === 'Confident') {
      summary = `Excellent execution on ${coin}. You kept a clear mind and executed a structured ${trade.type} trade. Entering at $${trade.entryPrice} with ${leverageVal}x leverage was balanced, leading to a secure gain of $${trade.pnlUsdt}. This represents professional trading discipline.`;
    } else {
      summary = `A profitable ${trade.type} scalp on ${coin} returning $${trade.pnlUsdt}, but notes reveal your emotional state was ${emotion}. While winners are nice, winning while emotional often instills bad habits. Ensure your technical setup justified this play completely.`;
    }
  } else {
    if (emotion === 'FOMO' || emotion === 'Greedy' || emotion === 'Revenge Trading') {
      summary = `A stressful losing ${trade.type} trade on ${coin} that resulted in a $${Math.abs(trade.pnlUsdt)} draw down. This was heavily influenced by your ${emotion} state. High leverages mixed with emotional entries inevitably trigger quick stop-outs or liquidations.`;
    } else {
      summary = `A losing ${trade.type} position on ${coin} resulting in a $${Math.abs(trade.pnlUsdt)} stop-out. Losses are a normal cost of business in trading, and your ${emotion} composure is admirable. Check if the structure was clean or if market conditions simply shifted.`;
    }
  }

  // 2. Mistakes & Warnings
  if (leverageVal >= 50) {
    mistakes.push(`Severe Over-leveraging: Using ${leverageVal}x leverage dramatically narrows your liquidation boundary, turning trading into pure gambling.`);
  } else if (leverageVal >= 20) {
    mistakes.push(`High Leverage Alert: ${leverageVal}x leverage raises your margin requirements and triggers emotional reactions to normal price wicks.`);
  }

  if (emotion === 'FOMO') {
    mistakes.push("FOMO Entry: You entered after a rapid expansion, buying the green candles near local peaks rather than waiting for structural support.");
  }
  if (emotion === 'Revenge Trading') {
    mistakes.push("Revenge Trade Catalyst: Entered a trade rapidly to recover previous platform losses, bypassing your normal strict checklist rules.");
  }
  if (emotion === 'Greedy') {
    mistakes.push("Greedy Targets: Position size or leverage parameters were oversized relative to account capital in pursuit of a fast jackpot.");
  }

  if (trade.riskRewardRatio > 0 && trade.riskRewardRatio < 1.5) {
    mistakes.push(`Inadequate Risk-to-Reward Ratio (${trade.riskRewardRatio}): Your active reward target is too small relative to your active risk. This requires a very high win-rate to stay profitable.`);
  }
  
  if (mistakes.length === 0) {
    mistakes.push("No technical or emotional mistakes identified. Excellent structural execution.");
  }

  // 3. What to Improve
  if (leverageVal >= 20) {
    improvements.push(`Reduce your standard perpetual leverage to below 10x on ${coin} to survive macro market dumps.`);
  }
  if (emotion === 'FOMO' || emotion === 'Revenge Trading') {
    improvements.push("Enforce a mandatory 2-hour offline cooling-down period after any trade output before opening a new position.");
    improvements.push("Wait for a clear, closed candle retest of key EMAs (21 or 50) before logging entries.");
  }
  if (!trade.stopLoss) {
    improvements.push("Always specify system-level Stop Loss orders inside the exchange interface.");
  } else {
    improvements.push("Practice trailing your Stop Loss to entry price after hitting 1R of profit to protect capital.");
  }

  if (improvements.length === 0) {
    improvements.push("Keep doing exactly what you did here: plan the trade, and execute the plan with precision.");
  }

  // 4. Next Trade Suggestion
  if (isLoss) {
    nextTrade = `For your next trade, pick a major index (BTC or ETH). Use a maximum leverage of 5x. Dedicate yourself to a slow swing play, taking a Calm mindset and targeting a minimum Risk-to-Reward ratio of 2.0.`;
  } else {
    nextTrade = `Maintain consistency. Your strategy on ${coin} worked beautifully. Ensure your next entry on ${coin} or similar asset has the identical technical confluence. Keep leverage constant at ${leverageVal}x.`;
  }

  return {
    tradeId: trade.id,
    performanceSummary: summary,
    mistakesWarnings: mistakes,
    improvements: improvements,
    nextTradeSuggestion: nextTrade,
    analyzedAt: new Date().toISOString()
  };
}
