import { Trade, EmotionalState } from '../types';

export function calculatePnL(
  entryPrice: number,
  exitPrice: number,
  positionSize: number,
  leverage: number,
  type: 'Long' | 'Short'
): { pnlUsdt: number; pnlPercent: number } {
  if (!entryPrice || !exitPrice || !positionSize) {
    return { pnlUsdt: 0, pnlPercent: 0 };
  }

  const priceRatio = (exitPrice - entryPrice) / entryPrice;
  const rawPnlPercent = priceRatio * 100 * leverage;
  const pnlPercent = type === 'Long' ? rawPnlPercent : -rawPnlPercent;
  
  // positionSize is cumulative margin * leverage or raw margin?
  // Let's assume positionSize is the USDT margin.
  const pnlUsdt = (pnlPercent / 100) * positionSize;

  return {
    pnlUsdt: parseFloat(pnlUsdt.toFixed(2)),
    pnlPercent: parseFloat(pnlPercent.toFixed(2))
  };
}

export function calculateRiskReward(
  entryPrice: number,
  stopLoss?: number,
  takeProfit?: number,
  type?: 'Long' | 'Short'
): number {
  if (!entryPrice || !stopLoss || !takeProfit) {
    return 0; // Return 0 or undefined if not specified
  }

  const isShort = type === 'Short';
  
  if (isShort) {
    const risk = stopLoss - entryPrice;
    const reward = entryPrice - takeProfit;
    if (risk <= 0 || reward <= 0) return 0;
    return parseFloat((reward / risk).toFixed(2));
  } else {
    const risk = entryPrice - stopLoss;
    const reward = takeProfit - entryPrice;
    if (risk <= 0 || reward <= 0) return 0;
    return parseFloat((reward / risk).toFixed(2));
  }
}

export function calculateWinRate(trades: Trade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter(t => t.pnlUsdt > 0).length;
  return parseFloat(((wins / trades.length) * 100).toFixed(1));
}

export function getEquityCurve(trades: Trade[]): { date: string; cumulativePnl: number }[] {
  if (trades.length === 0) return [];
  
  // Sort trades chronologically
  const sortedTrades = [...trades].sort((a, b) => 
    new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime()
  );

  let cumulativePnl = 0;
  const result = [{ date: 'Start', cumulativePnl: 0 }];

  sortedTrades.forEach(trade => {
    cumulativePnl += trade.pnlUsdt;
    const dateFormatted = new Date(trade.dateTime).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
    result.push({
      date: dateFormatted,
      cumulativePnl: parseFloat(cumulativePnl.toFixed(2))
    });
  });

  return result;
}

export function groupByEmotion(trades: Trade[]): { emotion: EmotionalState; avgPnl: number; count: number }[] {
  const emotions: EmotionalState[] = ['Calm', 'FOMO', 'Greedy', 'Fearful', 'Confident', 'Revenge Trading'];
  
  return emotions.map(emotion => {
    const emotionTrades = trades.filter(t => t.emotionalState === emotion);
    if (emotionTrades.length === 0) {
      return { emotion, avgPnl: 0, count: 0 };
    }
    const totalPnl = emotionTrades.reduce((sum, t) => sum + t.pnlUsdt, 0);
    return {
      emotion,
      avgPnl: parseFloat((totalPnl / emotionTrades.length).toFixed(2)),
      count: emotionTrades.length
    };
  });
}

export function groupByCoin(trades: Trade[]): { coin: string; pnl: number; count: number }[] {
  const coinMap: { [key: string]: { pnl: number; count: number } } = {};

  trades.forEach(trade => {
    const coin = trade.coinName.toUpperCase();
    if (!coinMap[coin]) {
      coinMap[coin] = { pnl: 0, count: 0 };
    }
    coinMap[coin].pnl += trade.pnlUsdt;
    coinMap[coin].count += 1;
  });

  return Object.keys(coinMap).map(coin => ({
    coin,
    pnl: parseFloat(coinMap[coin].pnl.toFixed(2)),
    count: coinMap[coin].count
  }));
}
