import { Trade, AIAnalysis } from '../types';
import { generateSmartMockResponse } from '../data/mockAIResponses';

/**
 * Service to analyze trade using Claude, OpenAI, or dynamic smart mock data.
 * Adheres strictly to the user's instructions.
 */
export async function analyzeTradeWithAI(trade: Trade): Promise<AIAnalysis> {
  const useRealAI = localStorage.getItem('tradejournal_use_real_ai') === 'true';
  const anthropicKey = localStorage.getItem('tradejournal_anthropic_key');
  const openaiKey = localStorage.getItem('tradejournal_openai_key');

  if (!useRealAI) {
    // Immediate smart mock fallback if Toggle is off
    return generateSmartMockResponse(trade);
  }

  const prompt = `You are an expert AI Crypto Trading Coach analyzing a trade.
Analyze the following trade parameters and provide actionable coaching advice:
- Coin: ${trade.coinName}
- Trade Type: ${trade.type}
- Entry Price: ${trade.entryPrice}
- Exit Price: ${trade.exitPrice}
- Position Size: ${trade.positionSize} USDT
- Leverage: ${trade.leverage}x
- Emotional State: ${trade.emotionalState}
- Trade Notes: "${trade.notes}"
- Profit/Loss: ${trade.pnlUsdt} USDT (${trade.pnlPercent}%)
- Risk/Reward Ratio: ${trade.riskRewardRatio}

You MUST return your analysis ONLY in the following strict JSON format, without markdown wrapping or backticks.
{
  "performanceSummary": "A concise paragraph summarizing their entry, exit, leverage, and emotional state.",
  "mistakesWarnings": [
    "Mistake or warning 1",
    "Mistake or warning 2"
  ],
  "improvements": [
    "Specific improvement suggestion 1",
    "Specific improvement suggestion 2"
  ],
  "nextTradeSuggestion": "Strong action-focused recommendation for their next trade based on this outcome."
}`;

  // 1. Try Claude first if key is present
  if (anthropicKey) {
    try {
      // Direct client fetch as requested (could trigger CORS, handled gracefully by fallback)
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': anthropicKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true' // standard Claude header for direct browser call
        },
        body: JSON.stringify({
          model: 'claude-3-5-sonnet-20241022', // Standard valid model
          max_tokens: 1500,
          messages: [{ role: 'user', content: prompt }]
        })
      });

      if (response.ok) {
        const data = await response.json();
        const contentText = data.content?.[0]?.text || '';
        const parsed = parseAIResponse(contentText);
        if (parsed) {
          return {
            tradeId: trade.id,
            ...parsed,
            analyzedAt: new Date().toISOString()
          };
        }
      }
    } catch (e) {
      console.warn("Claude API failed or was blocked by browser CORS. Trying fallback.", e);
    }
  }

  // 2. Try OpenAI fallback if key is present
  if (openaiKey) {
    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'You are a crypto trading mentor. Output JSON only.' },
            { role: 'user', content: prompt }
          ],
          response_format: { type: 'json_object' }
        })
      });

      if (response.ok) {
        const data = await response.json();
        const contentText = data.choices?.[0]?.message?.content || '';
        const parsed = parseAIResponse(contentText);
        if (parsed) {
          return {
            tradeId: trade.id,
            ...parsed,
            analyzedAt: new Date().toISOString()
          };
        }
      }
    } catch (e) {
      console.warn("OpenAI API call failed. Falling back to Smart Mocks.", e);
    }
  }

  // 3. Fallback to smart local mock response
  return generateSmartMockResponse(trade);
}

function parseAIResponse(content: string): {
  performanceSummary: string;
  mistakesWarnings: string[];
  improvements: string[];
  nextTradeSuggestion: string;
} | null {
  try {
    // Sanitize any markdown markdown code fence if AI included it
    let cleanContent = content.trim();
    if (cleanContent.startsWith('```json')) {
      cleanContent = cleanContent.slice(7);
    }
    if (cleanContent.startsWith('```')) {
      cleanContent = cleanContent.slice(3);
    }
    if (cleanContent.endsWith('```')) {
      cleanContent = cleanContent.slice(0, -3);
    }
    cleanContent = cleanContent.trim();
    
    return JSON.parse(cleanContent);
  } catch (e) {
    console.error("Failed to parse JSON response from AI", e);
    return null;
  }
}
