export type TradeType = 'Long' | 'Short';

export type EmotionalState = 'Calm' | 'FOMO' | 'Greedy' | 'Fearful' | 'Confident' | 'Revenge Trading';

export interface Trade {
  id: string;
  coinName: string;
  type: TradeType;
  entryPrice: number;
  exitPrice: number;
  positionSize: number;
  leverage: number;
  dateTime: string;
  exchange: string;
  emotionalState: EmotionalState;
  notes: string;
  pnlUsdt: number;
  pnlPercent: number;
  riskRewardRatio: number;
  stopLoss?: number;
  takeProfit?: number;
}

export interface AIAnalysis {
  tradeId: string;
  performanceSummary: string;
  mistakesWarnings: string[];
  improvements: string[];
  nextTradeSuggestion: string;
  analyzedAt: string;
}

export type ActiveTab = 'journal' | 'dashboard' | 'insights' | 'settings';
