import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Brain, Check, LayoutDashboard, Settings as SettingsIcon, Award, BookOpen, AlertCircle } from 'lucide-react';
import { ActiveTab, Trade, AIAnalysis } from './types';
import Sidebar from './components/Sidebar';
import TradeForm from './components/TradeForm';
import Dashboard from './components/Dashboard';
import AIInsightsView from './components/AIInsightsView';
import SettingsView from './components/SettingsView';
import { mockTrades } from './data/mockTrades';
import { mockAIResponses } from './data/mockAIResponses';
import { analyzeTradeWithAI } from './utils/aiService';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('journal');
  const [trades, setTrades] = useState<Trade[]>([]);
  const [analyses, setAnalyses] = useState<{ [tradeId: string]: AIAnalysis }>({});
  const [pendingAnalyses, setPendingAnalyses] = useState<{ [tradeId: string]: boolean }>({});
  
  // Track flags
  const [isDemoData, setIsDemoData] = useState(true);
  const [showWelcome, setShowWelcome] = useState(true);
  const [loggedFirstTrade, setLoggedFirstTrade] = useState(false);
  const [showSessionWelcome, setShowSessionWelcome] = useState(false);

  // Load state on start
  useEffect(() => {
    const storedTradesStr = localStorage.getItem('tradejournal_trades');
    const storedAnalysesStr = localStorage.getItem('tradejournal_analyses');
    const storedDemoFlag = localStorage.getItem('tradejournal_is_demo');
    const storedFirstTradeFlag = localStorage.getItem('tradejournal_logged_first');

    // Check session storage for first load welcome banner
    const sessionWelcomeDismissed = sessionStorage.getItem('tradejournal_session_welcome_dismissed');
    if (!sessionWelcomeDismissed) {
      setShowSessionWelcome(true);
    }

    if (storedTradesStr) {
      setTrades(JSON.parse(storedTradesStr));
      setIsDemoData(storedDemoFlag === 'true');
    } else {
      // First visit: Preload with 12 mock trades
      setTrades(mockTrades);
      localStorage.setItem('tradejournal_trades', JSON.stringify(mockTrades));
      
      setIsDemoData(true);
      localStorage.setItem('tradejournal_is_demo', 'true');
    }

    if (storedAnalysesStr) {
      setAnalyses(JSON.parse(storedAnalysesStr));
    } else {
      // Preload with mock AI responses
      setAnalyses(mockAIResponses);
      localStorage.setItem('tradejournal_analyses', JSON.stringify(mockAIResponses));
    }

    if (storedFirstTradeFlag) {
      setLoggedFirstTrade(storedFirstTradeFlag === 'true');
      setShowWelcome(false);
    } else if (storedTradesStr && JSON.parse(storedTradesStr).length > mockTrades.length) {
      // if they have more trades than mockup, hide welcome
      setLoggedFirstTrade(true);
      setShowWelcome(false);
    }
  }, []);

  // Sync back to local storage helper
  const saveTrades = (updatedTrades: Trade[]) => {
    setTrades(updatedTrades);
    localStorage.setItem('tradejournal_trades', JSON.stringify(updatedTrades));
  };

  const saveAnalyses = (updatedAnalyses: { [tradeId: string]: AIAnalysis }) => {
    setAnalyses(updatedAnalyses);
    localStorage.setItem('tradejournal_analyses', JSON.stringify(updatedAnalyses));
  };

  // Add a brand new Trade
  const handleAddTrade = async (newTrade: Trade) => {
    // Append to trade log
    const updated = [newTrade, ...trades];
    saveTrades(updated);

    // If it's a real trade added by user, toggle flags
    setLoggedFirstTrade(true);
    localStorage.setItem('tradejournal_logged_first', 'true');
    setShowWelcome(false);

    // Swap to dashboard view to see entry results instantly
    setActiveTab('dashboard');

    // Trigger AI compilation in background
    setPendingAnalyses((prev) => ({ ...prev, [newTrade.id]: true }));
    try {
      const generatedAnalysis = await analyzeTradeWithAI(newTrade);
      const updatedAnalyses = { ...analyses, [newTrade.id]: generatedAnalysis };
      saveAnalyses(updatedAnalyses);
    } catch (err) {
      console.error("AI coaching retrieval error:", err);
    } finally {
      setPendingAnalyses((prev) => ({ ...prev, [newTrade.id]: false }));
    }
  };

  // Trigger manual or inline analysis request
  const handleAnalyzeTrade = async (trade: Trade) => {
    setPendingAnalyses((prev) => ({ ...prev, [trade.id]: true }));
    try {
      const gAnalysis = await analyzeTradeWithAI(trade);
      const updatedAnalyses = { ...analyses, [trade.id]: gAnalysis };
      saveAnalyses(updatedAnalyses);
    } catch (err) {
      console.error(err);
    } finally {
      setPendingAnalyses((prev) => ({ ...prev, [trade.id]: false }));
    }
  };

  // Delete trade from ledger
  const handleDeleteTrade = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filtered = trades.filter(t => t.id !== id);
    saveTrades(filtered);

    // delete corresponding analysis from state to save memory
    const updatedAnalyses = { ...analyses };
    delete updatedAnalyses[id];
    saveAnalyses(updatedAnalyses);
  };

  // Reset local sandbox back to demo trades
  const handleResetToDemo = () => {
    saveTrades(mockTrades);
    saveAnalyses(mockAIResponses);
    setIsDemoData(true);
    localStorage.setItem('tradejournal_is_demo', 'true');
    setLoggedFirstTrade(false);
    localStorage.removeItem('tradejournal_logged_first');
    setShowWelcome(true);
    setActiveTab('dashboard');
  };

  // Clear demo indicator on dashboard
  const handleClearDemoData = () => {
    saveTrades([]);
    saveAnalyses({});
    setIsDemoData(false);
    localStorage.setItem('tradejournal_is_demo', 'false');
    setShowWelcome(true);
    setActiveTab('journal');
  };

  // Erase all ledger records
  const handleClearAll = () => {
    saveTrades([]);
    saveAnalyses({});
    setIsDemoData(false);
    localStorage.setItem('tradejournal_is_demo', 'false');
    setLoggedFirstTrade(false);
    localStorage.removeItem('tradejournal_logged_first');
    setShowWelcome(true);
    setActiveTab('journal');
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] text-gray-100 flex flex-col md:flex-row pb-16 md:pb-0 font-sans selection:bg-cyan/40 selection:text-white">
      
      {/* Sidebar Navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main View Area */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 min-h-screen max-w-7xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="space-y-6"
          >
            
            {/* 1. JOURNAL TAB */}
            {activeTab === 'journal' && (
              <div className="max-w-3xl mx-auto space-y-6">
                
                {/* Welcome alert for new users */}
                {showWelcome && !loggedFirstTrade && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-purple/10 border border-purple/20 rounded-2xl p-5 flex items-start gap-4 shadow-lg pr-8 relative"
                  >
                    <div className="bg-purple/15 p-2.5 rounded-xl text-purple shrink-0 mt-0.5 animate-bounce">
                      <Award className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <div>
                      <h3 className="font-display font-semibold text-white text-sm mb-1">
                        Welcome to your AI Trade Journal
                      </h3>
                      <p className="text-xs text-gray-400 leading-relaxed font-sans font-light">
                        Log your first perpetual trade to unlock cognitive evaluations. We've preloaded standard inputs to guide your entry. Give it a trial execute below!
                      </p>
                    </div>
                    <button 
                      onClick={() => setShowWelcome(false)}
                      className="absolute top-4 right-4 text-gray-500 hover:text-white font-mono text-xs font-semibold px-2 py-0.5 rounded hover:bg-white/5 transition-all text-[11px]"
                    >
                      dismiss
                    </button>
                  </motion.div>
                )}

                <TradeForm onAddTrade={handleAddTrade} />
              </div>
            )}

            {/* 2. DASHBOARD VIEW */}
            {activeTab === 'dashboard' && (
              <Dashboard
                trades={trades}
                analyses={analyses}
                onDeleteTrade={handleDeleteTrade}
                isDemoData={isDemoData}
                onClearDemoData={handleClearDemoData}
                onAnalyzeTrade={handleAnalyzeTrade}
                pendingAnalyses={pendingAnalyses}
              />
            )}

            {/* 3. COGNITIVE INSIGHTS VIEW */}
            {activeTab === 'insights' && (
              <AIInsightsView trades={trades} />
            )}

            {/* 4. SETTINGS VIEW */}
            {activeTab === 'settings' && (
              <SettingsView
                onResetToDemo={handleResetToDemo}
                onClearAll={handleClearAll}
                tradeCount={trades.length}
              />
            )}

          </motion.div>
        </AnimatePresence>

        {/* Builder Credit Footer */}
        <footer className="mt-16 pt-8 border-t border-white/5 pb-10 text-center flex flex-col items-center gap-3">
          <p className="text-[10px] font-mono text-gray-500 tracking-widest leading-loose">
            Built by <span className="text-gray-400 font-medium">@Ledora037</span> &middot; AI Trade Journal
          </p>
        </footer>
      </main>

      {/* Session-based Welcome Message Modal */}
      <AnimatePresence>
        {showSessionWelcome && (
          <div className="fixed inset-0 bg-[#060606ec] backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
            <motion.div
              initial={{ scale: 0.94, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.94, y: 15, opacity: 0 }}
              transition={{ type: 'spring', damping: 26, stiffness: 360 }}
              className="glass-card max-w-lg w-full border border-cyan/25 rounded-2xl p-6 md:p-8 bg-[#0d0d0dfa] relative overflow-hidden shadow-[0_0_50px_rgba(0,229,255,0.09)]"
            >
              <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-cyan via-purple to-cyan" />
              
              <div className="flex flex-col items-center text-center">
                <div className="bg-cyan/10 p-3.5 rounded-2xl text-cyan shadow-[0_0_20px_rgba(0,229,255,0.18)] mb-5">
                  <Sparkles className="w-8 h-8 stroke-[1.8]" />
                </div>
                
                <h2 className="font-display font-bold text-xl text-white tracking-tight mb-2">
                  AI Trade Journal Assistant
                </h2>
                
                <p className="text-xs text-gray-300 leading-relaxed font-sans font-light mb-6">
                  Welcome to AI Trade Journal Assistant — your smart crypto trading companion. Log your trades, get AI-powered analysis, track your emotions, and become a more consistent trader.
                </p>
                
                <button
                  onClick={() => {
                    sessionStorage.setItem('tradejournal_session_welcome_dismissed', 'true');
                    setShowSessionWelcome(false);
                  }}
                  className="w-full py-3 bg-[#00e5ff] hover:bg-[#00d4ec] text-black font-display font-bold text-xs rounded-xl active:scale-[0.98] transition-all cursor-pointer shadow-md tracking-wider uppercase"
                >
                  Enter Workspace
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
