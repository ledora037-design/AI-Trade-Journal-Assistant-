import React from 'react';
import { BookOpen, LayoutDashboard, BrainCircuit, Settings as SettingsIcon, TrendingUp } from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const tabs = [
    { id: 'journal' as ActiveTab, name: 'Journal', icon: BookOpen },
    { id: 'dashboard' as ActiveTab, name: 'Dashboard', icon: LayoutDashboard },
    { id: 'insights' as ActiveTab, name: 'AI Insights', icon: BrainCircuit },
    { id: 'settings' as ActiveTab, name: 'Settings', icon: SettingsIcon },
  ];

  return (
    <>
      {/* Desktop Sidebar (Left) */}
      <aside className="hidden md:flex flex-col w-64 h-screen fixed left-0 top-0 border-r border-[#ffffff0e] bg-[#0f0f0faf] backdrop-blur-md p-6 justify-between z-30">
        <div>
          {/* Logo Heading */}
          <div className="flex flex-col gap-3.5 mb-8 mt-2 px-2">
            <div className="flex items-center gap-3">
              <div className="bg-cyan p-2.5 rounded-xl text-black shadow-[0_0_15px_rgba(0,229,255,0.3)]">
                <TrendingUp className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div>
                <h1 className="font-display font-bold text-lg leading-tight tracking-tight bg-gradient-to-r from-white to-[#a3a3a3] bg-clip-text text-transparent">
                  Personal <span className="text-cyan font-extrabold">AI</span>
                </h1>
                <p className="text-[10px] font-mono tracking-wider text-gray-500 uppercase mt-0.5">
                  Trade Journal
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`sidebar-tab-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all duration-200 text-sm font-medium ${
                    isActive
                      ? 'bg-gradient-to-r from-[#1f2d34] to-[#121214] text-cyan border-l-2 border-cyan shadow-[0_4px_12px_rgba(0,0,0,0.2)]'
                      : 'text-gray-400 hover:text-white hover:bg-[#1a1a1a7f]'
                  }`}
                >
                  <Icon className={`w-[18px] h-[18px] ${isActive ? 'text-cyan' : 'text-gray-400 group-hover:text-white'}`} />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer Accent */}
        <div className="border-t border-[#ffffff08] pt-4 px-2">
          <div className="flex items-center gap-2 text-xs text-gray-500 font-mono">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Local Database Active</span>
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Tab Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#0f0f0ffd] border-t border-[#ffffff10] flex items-center justify-around px-2 z-40 shadow-[0_-8px_30px_rgba(0,0,0,0.5)]">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`mobile-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center justify-center w-16 h-12 rounded-xl transition-all duration-150 ${
                isActive ? 'text-cyan' : 'text-gray-500'
              }`}
            >
              <Icon className="w-5 h-5 mb-0.5" />
              <span className="text-[10px] font-medium tracking-tight">{tab.name}</span>
            </button>
          );
        })}
      </div>
    </>
  );
}
