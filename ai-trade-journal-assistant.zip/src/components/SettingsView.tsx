import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Settings, ShieldCheck, Key, RefreshCw, Trash2, Sliders, Check, Eye, EyeOff } from 'lucide-react';

interface SettingsViewProps {
  onResetToDemo: () => void;
  onClearAll: () => void;
  tradeCount: number;
}

export default function SettingsView({ onResetToDemo, onClearAll, tradeCount }: SettingsViewProps) {
  const [anthropicKey, setAnthropicKey] = useState('');
  const [openaiKey, setOpenaiKey] = useState('');
  const [useRealAI, setUseRealAI] = useState(false);
  
  // Visibility toggles
  const [showAnthropic, setShowAnthropic] = useState(false);
  const [showOpenai, setShowOpenai] = useState(false);
  const [savedFeedback, setSavedFeedback] = useState(false);

  // Load from localStorage on startup
  useEffect(() => {
    setAnthropicKey(localStorage.getItem('tradejournal_anthropic_key') || '');
    setOpenaiKey(localStorage.getItem('tradejournal_openai_key') || '');
    setUseRealAI(localStorage.getItem('tradejournal_use_real_ai') === 'true');
  }, []);

  const handleSaveKeys = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('tradejournal_anthropic_key', anthropicKey.trim());
    localStorage.setItem('tradejournal_openai_key', openaiKey.trim());
    localStorage.setItem('tradejournal_use_real_ai', String(useRealAI));

    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2500);
  };

  const handleToggleRealAI = (val: boolean) => {
    setUseRealAI(val);
    localStorage.setItem('tradejournal_use_real_ai', String(val));
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 1500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="max-w-3xl mx-auto space-y-6"
    >
      <div className="flex items-center gap-3">
        <div className="bg-cyan/10 p-2.5 rounded-xl text-cyan">
          <Settings className="w-5 h-5 leading-none" />
        </div>
        <div>
          <h2 className="font-display font-bold text-lg text-white">System Settings & API Keys</h2>
          <p className="text-xs text-gray-400">Configure real AI connections and manage local journal data</p>
        </div>
      </div>

      {/* API Key management form */}
      <form onSubmit={handleSaveKeys} className="glass-card rounded-2xl p-6 border border-white/5 space-y-5 relative">
        <div className="flex items-center gap-2 mb-2">
          <Key className="w-4 h-4 text-cyan text-cyan-450" />
          <h3 className="font-display font-semibold text-white text-sm">AI Configuration Credentials</h3>
        </div>

        {/* Real AI Toggle */}
        <div className="flex items-center justify-between p-4 bg-[#0d0d0d] rounded-xl border border-white/5">
          <div className="space-y-1 pr-4">
            <span className="text-xs font-mono font-bold text-white uppercase block leading-none">
              Use Real AI Analysis
            </span>
            <p className="text-[10px] text-gray-500 leading-normal font-sans">
              Engage active API requests to evaluate your notes and metrics. If disabled or credentials fail, we fall back to smart on-device mocks.
            </p>
          </div>
          <button
            type="button"
            onClick={() => handleToggleRealAI(!useRealAI)}
            className={`w-12 h-6 px-1 rounded-full transition-all flex items-center shrink-0 cursor-pointer ${
              useRealAI ? 'bg-cyan justify-end' : 'bg-gray-800 justify-start'
            }`}
          >
            <motion.div layout className="w-4.5 h-4.5 rounded-full bg-[#0a0a0a] shadow-inner" />
          </button>
        </div>

        {/* Anthropic field */}
        <div className="space-y-1.5">
          <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider">
            Anthropic (Claude) API Key (Preferred)
          </label>
          <div className="relative">
            <input
              type={showAnthropic ? 'text' : 'password'}
              value={anthropicKey}
              onChange={(e) => setAnthropicKey(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors pr-12 font-mono"
              placeholder="sk-ant-..."
            />
            <button
              type="button"
              onClick={() => setShowAnthropic(!showAnthropic)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 cursor-pointer"
            >
              {showAnthropic ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* OpenAI Field */}
        <div className="space-y-1.5">
          <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider">
            OpenAI API Key (Fallback)
          </label>
          <div className="relative">
            <input
              type={showOpenai ? 'text' : 'password'}
              value={openaiKey}
              onChange={(e) => setOpenaiKey(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors pr-12 font-mono"
              placeholder="sk-proj-..."
            />
            <button
              type="button"
              onClick={() => setShowOpenai(!showOpenai)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 cursor-pointer"
            >
              {showOpenai ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Info panel */}
        <div className="p-3 bg-emerald-500/5 rounded-lg border border-emerald-500/10 flex items-start gap-3">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <p className="text-[10px] text-emerald-400 leading-normal">
            <strong>Key Security:</strong> API keys are held exclusively inside your local browser storage (<code className="bg-emerald-500/10 px-1 rounded">localStorage</code>) and are transmitted directly from your client to Anthropic or OpenAI. They are never transmitted, cached, or compiled on third-party servers.
          </p>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-between border-t border-white/5 pt-4">
          <span className="text-xs text-gray-500">
            {savedFeedback ? (
              <span className="text-emerald-400 font-mono flex items-center gap-1.5 animate-pulse">
                <Check className="w-4 h-4" /> Parameters Commited!
              </span>
            ) : (
              'Save parameters to enable secure queries'
            )}
          </span>
          <button
            type="submit"
            className="px-5 py-2.5 bg-gradient-to-r from-cyan to-[#00b0ff] text-black font-display font-bold text-xs rounded-xl hover:opacity-90 transition-all cursor-pointer shadow-md"
          >
            Apply Settings
          </button>
        </div>
      </form>

      {/* Database reset and metrics administration */}
      <div className="glass-card rounded-2xl p-6 border border-white/5 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Sliders className="w-4 h-4 text-red-400" />
          <h3 className="font-display font-semibold text-white text-sm">Data System Operations</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Reset button */}
          <div className="border border-white/5 p-4 rounded-xl flex flex-col justify-between space-y-3">
            <div>
              <span className="text-xs font-mono font-bold text-white uppercase block leading-none">
                Restore Demo Logs
              </span>
              <p className="text-[10px] text-gray-500 leading-normal mt-1">
                Wipes current logs and resets the dataset back to the 12 default perpetual test trades with existing AI diagnostics.
              </p>
            </div>
            <button
              onClick={onResetToDemo}
              className="w-full py-2 bg-purple text-white hover:bg-opacity-90 font-display font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reset to Demo Database
            </button>
          </div>

          {/* Wipe button */}
          <div className="border border-white/5 p-4 rounded-xl flex flex-col justify-between space-y-3">
            <div>
              <span className="text-xs font-mono font-bold text-white uppercase block leading-none text-rose-450">
                Purge All Records
              </span>
              <p className="text-[10px] text-gray-500 leading-normal mt-1">
                Irreversibly deletes all logged trades and cached AI assessments from your browser's local sandbox memory.
              </p>
            </div>
            <button
              onClick={onClearAll}
              className="w-full py-2 bg-[#ff3d5e]/15 border border-red-500/20 text-rose-400 hover:bg-rose-500/20 font-display font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Purge Database ({tradeCount} entries)
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
