import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, ArrowUpDown, Trash2, Calendar, TrendingUp, TrendingDown,
  LineChart, PieChart, BarChart2, Smile, Sparkles, Filter, ChevronDown, ChevronUp, AlertCircle
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart as RechartsLineChart, Line, XAxis, YAxis, Tooltip,
  PieChart as RechartsPieChart, Pie, Cell, BarChart as RechartsBarChart, Bar, CartesianGrid
} from 'recharts';
import { Trade, AIAnalysis, EmotionalState } from '../types';
import { getEquityCurve, groupByEmotion, groupByCoin, calculateWinRate } from '../utils/calculations';
import StatsOverview from './StatsOverview';
import AIAnalysisPanel from './AIAnalysisPanel';

interface DashboardProps {
  trades: Trade[];
  analyses: { [tradeId: string]: AIAnalysis };
  onDeleteTrade: (id: string, e: React.MouseEvent) => void;
  isDemoData: boolean;
  onClearDemoData: () => void;
  onAnalyzeTrade: (trade: Trade) => Promise<void>;
  pendingAnalyses: { [tradeId: string]: boolean };
}

type SortField = 'dateTime' | 'coinName' | 'pnlUsdt' | 'positionSize';
type SortOrder = 'asc' | 'desc';

export default function Dashboard({
  trades,
  analyses,
  onDeleteTrade,
  isDemoData,
  onClearDemoData,
  onAnalyzeTrade,
  pendingAnalyses
}: DashboardProps) {
  // Filters & State
  const [searchTerm, setSearchTerm] = useState('');
  const [emotionFilter, setEmotionFilter] = useState<string>('all');
  const [sideFilter, setSideFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('dateTime');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  
  // Expanded row ID for inline AI Analysis
  const [expandedTradeId, setExpandedTradeId] = useState<string | null>(null);

  // Sorting handlers
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // Process data for charts
  const equityData = useMemo(() => getEquityCurve(trades), [trades]);

  const pieData = useMemo(() => {
    const wins = trades.filter(t => t.pnlUsdt > 0).length;
    const losses = trades.filter(t => t.pnlUsdt <= 0).length;
    return [
      { name: 'Wins', value: wins, color: '#10b981' }, // emerald-500
      { name: 'Losses', value: losses, color: '#f43f5e' } // rose-500
    ];
  }, [trades]);

  const pnlByCoinData = useMemo(() => groupByCoin(trades), [trades]);

  const emotionPnlData = useMemo(() => {
    const raw = groupByEmotion(trades);
    // filter emotions that have actual counts to make chart cleaner
    return raw.filter(item => item.count > 0);
  }, [trades]);

  // Filter and sort trades
  const filteredSortedTrades = useMemo(() => {
    return trades
      .filter((trade) => {
        const matchesSearch = trade.coinName.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesEmotion = emotionFilter === 'all' || trade.emotionalState === emotionFilter;
        const matchesSide = sideFilter === 'all' || trade.type === sideFilter;
        return matchesSearch && matchesEmotion && matchesSide;
      })
      .sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];

        if (sortField === 'dateTime') {
          const dateA = new Date(a.dateTime).getTime();
          const dateB = new Date(b.dateTime).getTime();
          return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
        }

        if (typeof valA === 'string') {
          valA = (valA as string).toLowerCase();
          valB = (valB as string).toLowerCase();
        }

        if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
        if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
        return 0;
      });
  }, [trades, searchTerm, emotionFilter, sideFilter, sortField, sortOrder]);

  const handleRowClick = async (trade: Trade) => {
    if (expandedTradeId === trade.id) {
      setExpandedTradeId(null);
    } else {
      setExpandedTradeId(trade.id);
      // Trigger API analysis if does not exist
      if (!analyses[trade.id] && !pendingAnalyses[trade.id]) {
        await onAnalyzeTrade(trade);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Demo banner */}
      {isDemoData && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-cyan/10 border border-cyan/20 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md"
        >
          <div className="flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-cyan text-cyan-450 shrink-0" />
            <p className="text-xs text-cyan/90 font-medium">
              Showing <span className="font-bold underline">12 Demo Trades</span> spread over the last 30 days. Log your own trading sets or wipe this sandbox to start fresh.
            </p>
          </div>
          <button
            onClick={onClearDemoData}
            className="px-4 py-2 bg-cyan text-black font-display font-bold text-xs rounded-xl hover:opacity-95 transition-all cursor-pointer whitespace-nowrap shadow-sm"
          >
            Clear Demo Data
          </button>
        </motion.div>
      )}

      {/* Stats Board */}
      <StatsOverview trades={trades} />

      {/* Charts Bento grid */}
      <h3 className="font-display font-semibold text-white text-base mt-2 flex items-center gap-2">
        <LineChart className="w-4 h-4 text-cyan" />
        Trading Intelligence Analytics
      </h3>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Equity Curve */}
        <div className="glass-card rounded-2xl p-5 border border-white/5 h-[340px] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] font-mono text-gray-500 uppercase">Growth History</span>
              <h4 className="font-display font-semibold text-white text-sm">Equity Curve (Cumulative P&L)</h4>
            </div>
            <LineChart className="w-4 h-4 text-gray-500" />
          </div>

          <div className="w-full h-[240px] mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsLineChart data={equityData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                <XAxis dataKey="date" stroke="#666" fontSize={9} fontClassName="font-mono" />
                <YAxis stroke="#666" fontSize={9} fontClassName="font-mono" tickFormatter={(v) => `${v}$`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#141414', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}
                  labelStyle={{ color: '#aaa', fontSize: 10, fontFamily: 'monospace' }}
                  itemStyle={{ fontSize: 11, fontFamily: 'monospace' }}
                />
                <Line
                  type="monotone"
                  dataKey="cumulativePnl"
                  stroke="#00e5ff"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#00e5ff', strokeWidth: 0 }}
                  activeDot={{ r: 5 }}
                />
              </RechartsLineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Win Ratio */}
        <div className="glass-card rounded-2xl p-5 border border-white/5 h-[340px] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] font-mono text-gray-500 uppercase">Hit rate check</span>
              <h4 className="font-display font-semibold text-white text-sm">Wins vs Losses Distribution</h4>
            </div>
            <PieChart className="w-4 h-4 text-purple" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 h-[240px] items-center">
            {/* Pie render */}
            <div className="w-full h-[180px]">
              <ResponsiveContainer width="100%" height="105%">
                <RechartsPieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#141414', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}
                    itemStyle={{ fontSize: 11, fontFamily: 'monospace' }}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>

            {/* Metrics column */}
            <div className="space-y-3 font-mono">
              {pieData.map((entry) => (
                <div key={entry.name} className="flex items-center justify-between border-b border-white/5 pb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="text-xs text-gray-400 font-sans">{entry.name}</span>
                  </div>
                  <span className="text-xs font-bold text-white leading-none">
                    {entry.value} ({trades.length > 0 ? ((entry.value / trades.length) * 100).toFixed(0) : 0}%)
                  </span>
                </div>
              ))}
              <div className="text-[11px] text-gray-500 leading-normal pl-4">
                Maintaining a win-rate above 50% combined with high average R/R multiples protects your trading capital securely.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 3: PnL by Coin */}
        <div className="glass-card rounded-2xl p-5 border border-white/5 h-[340px] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] font-mono text-gray-500 uppercase">Symbol efficiency</span>
              <h4 className="font-display font-semibold text-white text-sm">Total Profit / Loss by Coin (USDT)</h4>
            </div>
            <BarChart2 className="w-4 h-4 text-cyan" />
          </div>

          <div className="w-full h-[240px] mt-2">
            {pnlByCoinData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-gray-600">No coin metrics logged</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={pnlByCoinData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                  <XAxis dataKey="coin" stroke="#666" fontSize={9} fontClassName="font-mono" />
                  <YAxis stroke="#666" fontSize={9} fontClassName="font-mono" tickFormatter={(v) => `${v}$`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#141414', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}
                    itemStyle={{ fontSize: 11, fontFamily: 'monospace' }}
                  />
                  <Bar dataKey="pnl" fill="#00e5ff" radius={[4, 4, 0, 0]}>
                    {pnlByCoinData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? '#10b981' : '#f43f5e'} />
                    ))}
                  </Bar>
                </RechartsBarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Chart 4: Emotion vs Performance */}
        <div className="glass-card rounded-2xl p-5 border border-white/5 h-[340px] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] font-mono text-gray-500 uppercase">Cognitive discipline</span>
              <h4 className="font-display font-semibold text-white text-sm">Emotion vs Avg Performance (Avg P&L)</h4>
            </div>
            <Smile className="w-4 h-4 text-purple" />
          </div>

          <div className="w-full h-[240px] mt-2">
            {emotionPnlData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-gray-600">No emotional states tracked yet</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={emotionPnlData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                  <XAxis dataKey="emotion" stroke="#666" fontSize={8} />
                  <YAxis stroke="#666" fontSize={9} fontClassName="font-mono" tickFormatter={(v) => `${v}$`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#141414', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '12px' }}
                    itemStyle={{ fontSize: 11, fontFamily: 'monospace' }}
                  />
                  <Bar dataKey="avgPnl" fill="#a855f7" radius={[4, 4, 0, 0]}>
                    {emotionPnlData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.avgPnl >= 0 ? '#10b981' : '#f43f5e'} />
                    ))}
                  </Bar>
                </RechartsBarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* History Table block */}
      <h3 className="font-display font-semibold text-white text-base mt-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-cyan" />
          Trade History & Logs
        </div>
        <span className="font-mono text-xs text-gray-500 font-light">
          Showing {filteredSortedTrades.length} of {trades.length} entries
        </span>
      </h3>

      <div className="glass-card rounded-2xl p-4 border border-white/5 space-y-4">
        {/* Search & Filter toolbar */}
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Autocomplete-like search input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
            <input
              type="text"
              placeholder="Search by token (e.g. BTC)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl pl-11 pr-4 py-2 text-sm focus:outline-none transition-colors"
            />
          </div>

          {/* Emotion filter dropdown */}
          <div className="relative min-w-[140px]">
            <select
              value={emotionFilter}
              onChange={(e) => setEmotionFilter(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-2 text-sm focus:outline-none transition-colors text-gray-400"
            >
              <option value="all">🧠 All Emotions</option>
              {['Calm', 'Confident', 'FOMO', 'Greedy', 'Fearful', 'Revenge Trading'].map(e => (
                <option key={e} value={e}>{e}</option>
              ))}
            </select>
          </div>

          {/* Long/Short side filter */}
          <div className="relative min-w-[140px]">
            <select
              value={sideFilter}
              onChange={(e) => setSideFilter(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-2 text-sm focus:outline-none transition-colors text-gray-400"
            >
              <option value="all">🪐 All Sides</option>
              <option value="Long">🟢 Long</option>
              <option value="Short">🔴 Short</option>
            </select>
          </div>
        </div>

        {/* Scrollable grid table */}
        <div className="overflow-x-auto rounded-xl">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="border-b border-white/5 text-[10px] font-mono text-gray-500 uppercase tracking-widest bg-[#090909]">
                <th className="py-3 px-4 cursor-pointer hover:text-white select-none whitespace-nowrap" onClick={() => handleSort('dateTime')}>
                  <div className="flex items-center gap-1.5">
                    Date & Time {sortField === 'dateTime' && <ArrowUpDown className="w-3 h-3 text-cyan" />}
                  </div>
                </th>
                <th className="py-3 px-4 cursor-pointer hover:text-white select-none" onClick={() => handleSort('coinName')}>
                  <div className="flex items-center gap-1.5">
                    Coin {sortField === 'coinName' && <ArrowUpDown className="w-3 h-3 text-cyan" />}
                  </div>
                </th>
                <th className="py-3 px-4 whitespace-nowrap">Type</th>
                <th className="py-3 px-4 text-right">Entry</th>
                <th className="py-3 px-4 text-right">Exit</th>
                <th className="py-3 px-4 text-right cursor-pointer hover:text-white select-none" onClick={() => handleSort('positionSize')}>
                  <div className="flex items-center justify-end gap-1.5">
                    Size {sortField === 'positionSize' && <ArrowUpDown className="w-3 h-3 text-cyan" />}
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Leverage</th>
                <th className="py-3 px-4 text-right cursor-pointer hover:text-white select-none whitespace-nowrap" onClick={() => handleSort('pnlUsdt')}>
                  <div className="flex items-center justify-end gap-1.5">
                    P&L (USDT) {sortField === 'pnlUsdt' && <ArrowUpDown className="w-3 h-3 text-cyan" />}
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Emotion</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs text-gray-300">
              {filteredSortedTrades.map((trade) => {
                const isExpanded = expandedTradeId === trade.id;
                const pnl = trade.pnlUsdt;
                const isProfit = pnl >= 0;
                
                return (
                  <React.Fragment key={trade.id}>
                    {/* Row Item */}
                    <tr
                      onClick={() => handleRowClick(trade)}
                      className={`cursor-pointer hover:bg-white/5 transition-colors select-none ${
                        isExpanded ? 'bg-[#1b262a70] border-l-2 border-l-cyan' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500 whitespace-nowrap">
                        {new Date(trade.dateTime).toLocaleDateString([], { month: '2-digit', day: '2-digit' })}{' '}
                        {new Date(trade.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-white font-display">
                        {trade.coinName}/USDT
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          trade.type === 'Long'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {trade.type}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono">${trade.entryPrice.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-right font-mono">${trade.exitPrice.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-right font-mono">${trade.positionSize.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-center font-mono font-bold text-cyan">{trade.leverage}x</td>
                      <td className={`py-3.5 px-4 text-right font-mono font-semibold whitespace-nowrap ${
                        isProfit ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {isProfit ? '+' : ''}{pnl.toFixed(2)} ({isProfit ? '+' : ''}{trade.pnlPercent.toFixed(1)}%)
                      </td>
                      <td className="py-3.5 px-4 text-center text-sm no-scrollbar whitespace-nowrap" title={trade.emotionalState}>
                        {trade.emotionalState === 'Calm' && '🧘'}
                        {trade.emotionalState === 'Confident' && '⚡'}
                        {trade.emotionalState === 'FOMO' && '🔥'}
                        {trade.emotionalState === 'Greedy' && '🤑'}
                        {trade.emotionalState === 'Fearful' && '😰'}
                        {trade.emotionalState === 'Revenge Trading' && '🤬'}
                        <span className="text-[10px] text-gray-500 font-mono ml-1 hidden md:inline-block leading-none">{trade.emotionalState}</span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteTrade(trade.id, e);
                            }}
                            className="text-gray-600 hover:text-rose-400 p-1 rounded hover:bg-white/5 transition-all"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <span>{isExpanded ? <ChevronUp className="w-3.5 h-3.5 text-cyan" /> : <ChevronDown className="w-3.5 h-3.5" />}</span>
                        </div>
                      </td>
                    </tr>

                    {/* Expand Row for AI Analysis */}
                    <AnimatePresence>
                      {isExpanded && (
                        <tr>
                          <td colSpan={10} className="p-0 bg-[#0c0c0c]">
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.25 }}
                              className="overflow-hidden border-b border-white/5"
                            >
                              <div className="p-5 space-y-4 max-w-5xl mx-auto">
                                {/* Notes block */}
                                <div className="p-4 bg-[#141414] rounded-xl border border-white/5 space-y-1.5">
                                  <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest block font-bold leading-none">
                                    Trader Execution Notes & Strategy Triggers
                                  </span>
                                  <p className="text-xs text-gray-400 italic font-light">
                                    "{trade.notes || 'No custom notes provided for this trade play.'}"
                                  </p>
                                </div>

                                {/* AI Coacher integration */}
                                <AIAnalysisPanel
                                  analysis={analyses[trade.id] || null}
                                  trade={trade}
                                  isLoading={pendingAnalyses[trade.id] || false}
                                />
                              </div>
                            </motion.div>
                          </td>
                        </tr>
                      )}
                    </AnimatePresence>
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Empty records status */}
        {filteredSortedTrades.length === 0 && (
          <div className="py-12 text-center text-gray-600 text-xs font-mono">
            No matching perpetual records found. Add position logs to load charts.
          </div>
        )}
      </div>
    </div>
  );
}
