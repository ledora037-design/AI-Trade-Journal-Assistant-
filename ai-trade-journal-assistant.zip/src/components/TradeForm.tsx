import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Calendar, DollarSign, PenTool, Hash, AlertTriangle, Check } from 'lucide-react';
import { Trade, EmotionalState, TradeType } from '../types';
import { calculatePnL, calculateRiskReward } from '../utils/calculations';

interface TradeFormProps {
  onAddTrade: (trade: Trade) => Promise<void>;
}

const POPULAR_COINS = ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'PEPE', 'WIF', 'TON'];

const EMOTIONAL_STATES = [
  { value: 'Calm', label: '🧘 Calm', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
  { value: 'Confidence', label: '⚡ Confident', color: 'text-cyan-450 bg-cyan-500/10 border-cyan-500/20' },
  { value: 'FOMO', label: '🔥 FOMO (Fear of Missing Out)', color: 'text-amber-500 bg-amber-550/10 border-amber-500/20' },
  { value: 'Greedy', label: '🤑 Greedy', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
  { value: 'Fearful', label: '😰 Fearful', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' },
  { value: 'Revenge Trading', label: '🤬 Revenge Trading', color: 'text-purple bg-purple/10 border-purple/20' }
];

const LEVERAGES = [1, 2, 5, 10, 20, 50, 100];

export default function TradeForm({ onAddTrade }: TradeFormProps) {
  // Input fields
  const [coinName, setCoinName] = useState('BTC');
  const [showCoinSuggestions, setShowCoinSuggestions] = useState(false);
  const [tradeType, setTradeType] = useState<TradeType>('Long');
  const [entryPrice, setEntryPrice] = useState<string>('65000');
  const [exitPrice, setExitPrice] = useState<string>('66500');
  const [positionSize, setPositionSize] = useState<string>('100');
  const [leverage, setLeverage] = useState<number>(10);
  const [dateTime, setDateTime] = useState<string>(() => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  });
  const [emotionalState, setEmotionalState] = useState<EmotionalState>('Calm');
  const [stopLoss, setStopLoss] = useState<string>('64000');
  const [takeProfit, setTakeProfit] = useState<string>('68000');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live Auto-Calculations
  const [livePnlUsdt, setLivePnlUsdt] = useState(0);
  const [livePnlPercent, setLivePnlPercent] = useState(0);
  const [liveRr, setLiveRr] = useState(0);

  // Recalculate values in real-time as user types
  useEffect(() => {
    const entry = parseFloat(entryPrice) || 0;
    const exit = parseFloat(exitPrice) || 0;
    const size = parseFloat(positionSize) || 0;
    const sl = parseFloat(stopLoss) || undefined;
    const tp = parseFloat(takeProfit) || undefined;

    const { pnlUsdt, pnlPercent } = calculatePnL(entry, exit, size, leverage, tradeType);
    const rr = calculateRiskReward(entry, sl, tp, tradeType);

    setLivePnlUsdt(pnlUsdt);
    setLivePnlPercent(pnlPercent);
    setLiveRr(rr);
  }, [coinName, tradeType, entryPrice, exitPrice, positionSize, leverage, stopLoss, takeProfit]);

  // Handle Autocomplete selection
  const handleSelectCoin = (coin: string) => {
    setCoinName(coin);
    setShowCoinSuggestions(false);
    
    // Auto populate sample reasonable prices for comfort
    if (coin === 'BTC') {
      setEntryPrice('65000');
      setExitPrice('66500');
      setStopLoss('64000');
      setTakeProfit('68000');
    } else if (coin === 'ETH') {
      setEntryPrice('3400');
      setExitPrice('3520');
      setStopLoss('3300');
      setTakeProfit('3650');
    } else if (coin === 'SOL') {
      setEntryPrice('170');
      setExitPrice('182');
      setStopLoss('163');
      setTakeProfit('195');
    } else if (coin === 'DOGE') {
      setEntryPrice('0.14');
      setExitPrice('0.155');
      setStopLoss('0.13');
      setTakeProfit('0.18');
    } else if (coin === 'PEPE') {
      setEntryPrice('0.000012');
      setExitPrice('0.000014');
      setStopLoss('0.000011');
      setTakeProfit('0.000018');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!coinName) return;

    setIsSubmitting(true);
    const entry = parseFloat(entryPrice) || 0;
    const exit = parseFloat(exitPrice) || 0;
    const size = parseFloat(positionSize) || 0;
    const sl = parseFloat(stopLoss) || undefined;
    const tp = parseFloat(takeProfit) || undefined;

    const { pnlUsdt, pnlPercent } = calculatePnL(entry, exit, size, leverage, tradeType);
    const rr = calculateRiskReward(entry, sl, tp, tradeType);

    const newTrade: Trade = {
      id: `trade-${Date.now()}`,
      coinName: coinName.toUpperCase().replace('/USDT', ''),
      type: tradeType,
      entryPrice: entry,
      exitPrice: exit,
      positionSize: size,
      leverage,
      dateTime,
      exchange: 'Unified',
      emotionalState,
      notes: notes.trim(),
      pnlUsdt,
      pnlPercent,
      riskRewardRatio: rr,
      stopLoss: sl,
      takeProfit: tp
    };

    try {
      await onAddTrade(newTrade);
      // Success feedback animation & partial form reset
      setNotes('');
      // set new prices slightly different so they feel refreshed
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const isProfit = livePnlUsdt >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="glass-card rounded-2xl p-6 border border-[#ffffff0a] shadow-xl relative overflow-hidden"
    >
      {/* Decorative colored glow on background */}
      <div className="absolute -top-10 -right-10 w-44 h-44 bg-cyan/5 rounded-full blur-3xl" />
      <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-purple/5 rounded-full blur-3xl" />

      <h2 className="font-display font-semibold text-lg mb-6 flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-cyan text-cyan-450 animate-pulse" />
        Log Perpetual Position
      </h2>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Toggle Buy/Long vs Sell/Short */}
        <div>
          <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-2">
            Order Side
          </label>
          <div className="grid grid-cols-2 gap-3 p-1 bg-[#090909] rounded-xl border border-[#ffffff05]">
            <button
              type="button"
              onClick={() => setTradeType('Long')}
              className={`py-3 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
                tradeType === 'Long'
                  ? 'bg-emerald-500/20 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)] border border-emerald-500/30'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <span className={`w-2 h-2 rounded-full bg-emerald-400 ${tradeType === 'Long' ? 'animate-ping' : ''}`} />
              Buy / Long
            </button>
            <button
              type="button"
              onClick={() => setTradeType('Short')}
              className={`py-3 rounded-lg text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2 ${
                tradeType === 'Short'
                  ? 'bg-rose-500/20 text-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.15)] border border-rose-500/30'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <span className={`w-2 h-2 rounded-full bg-rose-400 ${tradeType === 'Short' ? 'animate-ping' : ''}`} />
              Sell / Short
            </button>
          </div>
        </div>

        {/* 2-Column Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Coin Name with Autocomplete */}
          <div className="relative">
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Coin Name
            </label>
            <input
              type="text"
              value={coinName}
              onChange={(e) => {
                setCoinName(e.target.value.toUpperCase());
                setShowCoinSuggestions(true);
              }}
              onFocus={() => setShowCoinSuggestions(true)}
              onBlur={() => setTimeout(() => setShowCoinSuggestions(false), 200)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors"
              placeholder="e.g. BTC"
            />
            
            {showCoinSuggestions && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-[#141414] border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden no-scrollbar">
                <p className="text-[10px] font-mono text-gray-500 uppercase px-3 py-1.5 bg-[#090909] border-b border-white/5">
                  Suggested Pairs
                </p>
                <div className="grid grid-cols-2 gap-1 p-1 max-h-40 overflow-y-auto">
                  {POPULAR_COINS.filter(c => c.includes(coinName.toUpperCase() || '')).map((coin) => (
                    <button
                      key={coin}
                      type="button"
                      onMouseDown={() => handleSelectCoin(coin)}
                      className="px-3 py-2 text-xs text-left text-gray-300 hover:text-cyan hover:bg-white/5 rounded-lg transition-colors flex items-center justify-between"
                    >
                      <span>{coin}/USDT</span>
                      <Check className="w-3 h-3 opacity-0 group-hover:opacity-100 text-cyan" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Exchange Indicator (Locked to Unified Account) */}
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Exchange
            </label>
            <div className="w-full bg-[#0d0d0d]/40 border border-[#4ee2ef]/15 text-cyan/90 font-mono rounded-xl px-4 py-3 text-sm font-semibold tracking-wider select-none flex items-center justify-between">
              <span>UNIFIED</span>
              <span className="text-[10px] bg-cyan/10 text-cyan border border-cyan/20 px-2 py-0.5 rounded-full font-sans uppercase font-medium">
                Unified Perp
              </span>
            </div>
          </div>
        </div>

        {/* 3-Column Inputs: Entry, Exit, Leverage */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Entry Price ($)
            </label>
            <input
              type="number"
              step="any"
              required
              value={entryPrice}
              onChange={(e) => setEntryPrice(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors text-emerald-400"
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Exit Price ($)
            </label>
            <input
              type="number"
              step="any"
              required
              value={exitPrice}
              onChange={(e) => setExitPrice(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors text-rose-400"
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Leverage Ratio
            </label>
            <select
              value={leverage}
              onChange={(e) => setLeverage(parseInt(e.target.value))}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors"
            >
              {LEVERAGES.map((lev) => (
                <option key={lev} value={lev}>
                  {lev}x
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Leverage quick presets */}
        <div className="flex gap-2 justify-end -mt-2">
          {LEVERAGES.map((lev) => (
            <button
              key={`preset-${lev}`}
              type="button"
              onClick={() => setLeverage(lev)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-all ${
                leverage === lev
                  ? 'border-cyan/40 text-cyan bg-cyan/5'
                  : 'border-white/5 text-gray-500 hover:text-gray-300'
              }`}
            >
              {lev}x
            </button>
          ))}
        </div>

        {/* Positioning Metrics: Margin, DateTime */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Margin Size (USDT)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-mono">$</span>
              <input
                type="number"
                step="any"
                required
                value={positionSize}
                onChange={(e) => setPositionSize(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl pl-8 pr-4 py-3 text-sm focus:outline-none transition-colors font-mono"
                placeholder="100.00"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Date & Time (UTC)
            </label>
            <div className="relative">
              <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
              <input
                type="datetime-local"
                required
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors text-gray-400"
              />
            </div>
          </div>
        </div>

        {/* Stop Loss & Take Profit (Crucial for Risk/Reward calculating) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Stop Loss Price ($) <span className="text-[10px] text-gray-500 lowercase">(optional)</span>
            </label>
            <input
              type="number"
              step="any"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-rose-500/30 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors font-mono text-rose-300"
              placeholder="S/L trigger"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
              Take Profit Price ($) <span className="text-[10px] text-gray-500 lowercase">(optional)</span>
            </label>
            <input
              type="number"
              step="any"
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-emerald-500/30 rounded-xl px-4 py-3 text-sm focus:outline-none transition-colors font-mono text-emerald-300"
              placeholder="T/P target"
            />
          </div>
        </div>

        {/* Live Auto-calculations board */}
        <div className="bg-[#0a0a0add] rounded-xl p-4 border border-[#ffffff04] grid grid-cols-3 gap-2">
          <div className="text-center border-r border-white/5">
            <p className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-0.5">Live P&L</p>
            <span className={`text-sm font-semibold font-mono ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isProfit ? '+' : ''}{livePnlUsdt} USDT
            </span>
          </div>
          <div className="text-center border-r border-white/5">
            <p className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-0.5">Live P&L %</p>
            <span className={`text-sm font-semibold font-mono ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isProfit ? '+' : ''}{livePnlPercent}%
            </span>
          </div>
          <div className="text-center">
            <p className="text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-0.5">Risk/Reward</p>
            <span className={`text-sm font-semibold font-mono ${liveRr > 0 ? 'text-cyan-450 text-cyan animate-pulse' : 'text-gray-400'}`}>
              {liveRr > 0 ? `1 : ${liveRr}` : 'N/A'}
            </span>
          </div>
        </div>

        {/* Emotional State Dropdown */}
        <div>
          <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
            Emotional State Entry Composure
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {EMOTIONAL_STATES.map((state) => {
              const isSelected = emotionalState === state.value;
              return (
                <button
                  key={state.value}
                  type="button"
                  onClick={() => setEmotionalState(state.value as EmotionalState)}
                  className={`px-3 py-2.5 rounded-xl border text-xs font-medium transition-all text-left flex items-center justify-between ${
                    isSelected
                      ? `${state.color} border-white/20 text-white scale-[1.03] shadow-md ring-1 ring-cyan/20`
                      : 'bg-[#0d0d0d] border-[#ffffff05] text-gray-400 hover:text-gray-300 hover:bg-[#121212]'
                  }`}
                >
                  <span className="truncate">{state.label}</span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-cyan-450 bg-cyan" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Trade Notes */}
        <div>
          <label className="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1.5">
            Trade notes & strategy triggers
          </label>
          <div className="relative">
            <PenTool className="absolute left-4 top-3.5 w-4 h-4 text-gray-600 pointer-events-none" />
            <textarea
              rows={3}
              required
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-white/5 focus:border-cyan/40 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none transition-colors placeholder:text-gray-700"
              placeholder="What chart patterns drew you in? What was your plan? S/L execution..."
            />
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-gradient-to-r from-cyan to-purple text-black hover:opacity-90 font-display font-bold py-3.5 rounded-xl transition-all shadow-[0_4px_20px_rgba(0,229,255,0.15)] flex items-center justify-center gap-2 cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isSubmitting ? (
            <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Sparkles className="w-4 h-4 stroke-[2.5] text-black" />
              Analyze & Log Trade with AI
            </>
          )}
        </button>
      </form>
    </motion.div>
  );
}
