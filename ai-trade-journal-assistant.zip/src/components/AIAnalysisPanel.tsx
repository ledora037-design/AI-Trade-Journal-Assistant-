import React from 'react';
import { motion } from 'motion/react';
import { Brain, AlertCircle, TrendingUp, CheckCircle, ShieldAlert } from 'lucide-react';
import { AIAnalysis, Trade } from '../types';

interface AIAnalysisPanelProps {
  analysis: AIAnalysis | null;
  trade: Trade | null;
  isLoading: boolean;
}

export default function AIAnalysisPanel({ analysis, trade, isLoading }: AIAnalysisPanelProps) {
  if (isLoading) {
    return (
      <div className="glass-card rounded-2xl p-8 border border-cyan/10 flex flex-col items-center justify-center min-h-[350px] relative overflow-hidden">
        {/* Glowing backdrop particle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-cyan/10 rounded-full blur-3xl animate-pulse" />
        
        {/* Animated brain scan layout */}
        <div className="relative mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
            className="w-16 h-16 rounded-full border border-dashed border-cyan/30 flex items-center justify-center"
          />
          <Brain className="w-8 h-8 text-cyan absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-bounce text-cyan-450" />
        </div>

        <h3 className="font-display font-semibold text-white text-base mb-2">
          Consulting AI Crypto Coach...
        </h3>
        <p className="text-xs text-gray-500 max-w-sm text-center font-mono leading-relaxed">
          Analyzing order books, checking entry execution, risk boundaries, and evaluating "{trade?.emotionalState || 'Calm'}" cognitive state.
        </p>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="glass-card rounded-2xl p-8 border border-white/5 flex flex-col items-center justify-center min-h-[350px] text-center">
        <Brain className="w-10 h-10 text-gray-600 mb-4" />
        <h3 className="font-display font-medium text-gray-400 text-sm mb-1">
          No Trade Selected for AI Performance Review
        </h3>
        <p className="text-xs text-gray-500 max-w-xs leading-relaxed">
          Log a trade in the Journal or click on any database history row to expand the automated technical coaching files.
        </p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-5"
    >
      {/* Title Card */}
      <div className="glass-card rounded-2xl p-5 border-l-4 border-l-cyan border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-cyan/10 p-2.5 rounded-xl text-cyan text-cyan-450">
            <Brain className="w-5 h-5 leading-none" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-widest leading-none">
              AI Assistant Review
            </span>
            <h3 className="font-display font-semibold text-white text-sm mt-0.5">
              AI Coach Executive Report ({trade?.coinName}/USDT)
            </h3>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[9px] font-mono text-gray-500 uppercase block">Reviewed at</span>
          <span className="text-[10px] font-mono text-cyan block mt-0.5">
            {new Date(analysis.analyzedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. Performance Summary */}
        <div className="glass-card rounded-2xl p-5 border border-white/5">
          <div className="flex items-center gap-2.5 border-b border-white/5 pb-3 mb-4">
            <TrendingUp className="w-4 h-4 text-cyan text-cyan-455" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-gray-300">
              1. Trade Performance Analysis
            </span>
          </div>
          <p className="text-xs text-gray-300 leading-relaxed font-sans font-light">
            {analysis.performanceSummary}
          </p>
        </div>

        {/* 2. Mistakes & Warnings */}
        <div className="glass-card rounded-2xl p-5 border border-white/5">
          <div className="flex items-center gap-2.5 border-b border-white/5 pb-3 mb-4">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">
              2. Structural Mistakes & Warnings
            </span>
          </div>
          <ul className="space-y-2.5">
            {analysis.mistakesWarnings.map((mistake, idx) => (
              <li key={`mistake-${idx}`} className="flex gap-2.5 text-xs text-gray-400">
                <span className="text-amber-500 font-bold shrink-0 mt-0.5">❌</span>
                <span className="leading-relaxed">{mistake}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 3. What to Improve */}
        <div className="glass-card rounded-2xl p-5 border border-white/5">
          <div className="flex items-center gap-2.5 border-b border-white/5 pb-3 mb-4">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
              3. Practical Coaching Upgrades
            </span>
          </div>
          <ul className="space-y-2.5">
            {analysis.improvements.map((imp, idx) => (
              <li key={`improve-${idx}`} className="flex gap-2.5 text-xs text-gray-400">
                <span className="text-emerald-500 font-bold shrink-0 mt-0.5">✅</span>
                <span className="leading-relaxed">{imp}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* 4. Next Trade Suggestion */}
        <div className="glass-card rounded-2xl p-5 border border-purple/20 bg-purple/5">
          <div className="flex items-center gap-2.5 border-b border-purple/20 pb-3 mb-4">
            <AlertCircle className="w-4 h-4 text-purple" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-purple">
              4. Next Trade Strategy Suggestion
            </span>
          </div>
          <p className="text-xs text-gray-300 leading-relaxed font-sans font-light">
            {analysis.nextTradeSuggestion}
          </p>
        </div>
      </div>
    </motion.div>
  );
}
