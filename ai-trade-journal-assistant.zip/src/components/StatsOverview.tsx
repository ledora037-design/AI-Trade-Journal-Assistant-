import React from 'react';
import { motion } from 'motion/react';
import { Award, Percent, DollarSign, ArrowUpRight, ArrowDownRight, Scale, TrendingUp } from 'lucide-react';
import { Trade } from '../types';
import { calculateWinRate } from '../utils/calculations';

interface StatsOverviewProps {
  trades: Trade[];
}

export default function StatsOverview({ trades }: StatsOverviewProps) {
  const totalTrades = trades.length;
  const winRate = calculateWinRate(trades);
  const totalPnL = trades.reduce((sum, t) => sum + t.pnlUsdt, 0);
  
  const profitableTrades = trades.filter(t => t.pnlUsdt > 0);
  const losingTrades = trades.filter(t => t.pnlUsdt < 0);

  // Best trade
  const bestTrade = trades.length > 0 
    ? Math.max(...trades.map(t => t.pnlUsdt)) 
    : 0;

  // Worst trade
  const worstTrade = trades.length > 0 
    ? Math.min(...trades.map(t => t.pnlUsdt)) 
    : 0;

  // Average R/R
  const tradesWithRr = trades.filter(t => t.riskRewardRatio && t.riskRewardRatio > 0);
  const avgRr = tradesWithRr.length > 0
    ? parseFloat((tradesWithRr.reduce((sum, t) => sum + (t.riskRewardRatio || 0), 0) / tradesWithRr.length).toFixed(2))
    : 0;

  const stats = [
    {
      id: 'stat-total',
      name: 'Total Trades',
      value: totalTrades,
      icon: TrendingUp,
      desc: 'Cumulative recorded sets',
      color: 'text-gray-200 border-white/5 bg-[#14141470]',
    },
    {
      id: 'stat-winrate',
      name: 'Win Rate %',
      value: `${winRate}%`,
      icon: Percent,
      desc: `${profitableTrades.length} Wins / ${losingTrades.length} Losses`,
      color: 'text-emerald-400 border-emerald-500/10 bg-emerald-500/5',
      extra: (
        <div className="w-full bg-[#0a0a0a] rounded-full h-1 mt-2.5 overflow-hidden">
          <div 
            className="bg-emerald-400 h-1 rounded-full transition-all duration-300" 
            style={{ width: `${winRate}%` }} 
          />
        </div>
      )
    },
    {
      id: 'stat-pnl',
      name: 'Total P&L',
      value: `${totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)} USDT`,
      icon: DollarSign,
      desc: 'Net portfolio margin return',
      color: totalPnL >= 0 ? 'text-emerald-400 border-emerald-500/10 bg-emerald-500/5' : 'text-rose-400 border-rose-500/10 bg-rose-500/5',
    },
    {
      id: 'stat-best',
      name: 'Best Trade',
      value: `+$${bestTrade.toFixed(2)}`,
      icon: ArrowUpRight,
      desc: 'Peak single profit logged',
      color: 'text-emerald-400 border-emerald-500/10 bg-emerald-500/5',
    },
    {
      id: 'stat-worst',
      name: 'Worst Trade',
      value: `${worstTrade < 0 ? '-' : ''}$${Math.abs(worstTrade).toFixed(2)}`,
      icon: ArrowDownRight,
      desc: 'Max single drawdown hit',
      color: 'text-rose-400 border-rose-500/10 bg-rose-500/5',
    },
    {
      id: 'stat-rr',
      name: 'Avg R/R Ratio',
      value: avgRr > 0 ? `1 : ${avgRr}` : 'N/A',
      icon: Scale,
      desc: 'Technical performance multiple',
      color: 'text-cyan border-cyan/10 bg-cyan/5',
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
            className={`border rounded-2xl p-4 flex flex-col justify-between shadow-sm relative overflow-hidden backdrop-blur-md ${stat.color}`}
          >
            {/* Soft decorative visual cue */}
            <div className="absolute top-0 right-0 p-3 opacity-5">
              <Icon className="w-16 h-16" />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-medium text-gray-400 tracking-tight uppercase leading-none">
                  {stat.name}
                </span>
                <Icon className="w-4 h-4 text-gray-500" />
              </div>

              <div className="mt-3">
                <h3 className="text-lg md:text-xl font-display font-bold font-mono tracking-tight text-white">
                  {stat.value}
                </h3>
                <p className="text-[10px] text-gray-500 mt-1 truncate">
                  {stat.desc}
                </p>
              </div>
            </div>

            {stat.extra}
          </motion.div>
        );
      })}
    </div>
  );
}
