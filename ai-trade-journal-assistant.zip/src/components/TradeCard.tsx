import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Trash2, TrendingUp, TrendingDown, BrainCircuit } from 'lucide-react';
import { Trade } from '../types';

interface TradeCardProps {
  trade: Trade;
  isSelected?: boolean;
  onSelect?: (trade: Trade) => void;
  onDelete?: (id: string, e: React.MouseEvent) => void;
}

export default function TradeCard({ trade, isSelected, onSelect, onDelete }: TradeCardProps) {
  const isProfit = trade.pnlUsdt >= 0;
  
  const getEmotionEmoji = (emotion: string) => {
    switch (emotion) {
      case 'Calm': return '🧘';
      case 'Confident': return '⚡';
      case 'FOMO': return '🔥';
      case 'Greedy': return '🤑';
      case 'Fearful': return '😰';
      case 'Revenge Trading': return '🤬';
      default: return '😐';
    }
  };

  const formattedDate = new Date(trade.dateTime).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={() => onSelect?.(trade)}
      className={`glass-card-interactive rounded-2xl p-5 border cursor-pointer relative overflow-hidden flex flex-col justify-between h-full ${
        isSelected
          ? 'border-cyan bg-cyan/5 shadow-[0_0_15px_rgba(0,229,255,0.06)] scale-[1.01]'
          : 'border-white/5 bg-[#14141470]'
      }`}
    >
      {/* Dynamic side accent bar based on profit vs loss */}
      <div 
        className={`absolute left-0 top-0 bottom-0 w-1.5 ${
          isProfit ? 'bg-emerald-500' : 'bg-rose-500'
        }`}
      />

      {/* Header Info */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-base text-white tracking-tight">
              {trade.coinName}/USDT
            </span>
            <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
              trade.type === 'Long'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                : 'bg-rose-500/15 text-rose-400 border border-rose-500/20'
            }`}>
              {trade.type} {trade.leverage}x
            </span>
          </div>
          
          <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono mt-1.5">
            <Calendar className="w-3 h-3" />
            <span>{formattedDate}</span>
          </div>
        </div>

        {/* Action button */}
        {onDelete && (
          <button
            onClick={(e) => onDelete(trade.id, e)}
            className="text-gray-600 hover:text-rose-400 p-1.5 rounded-lg hover:bg-white/5 transition-all cursor-pointer"
            title="Delete trade"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Trade P&L results */}
      <div className="my-5 flex items-baseline justify-between select-none">
        <div>
          <span className="text-[10px] font-mono text-gray-500 uppercase block tracking-wider">
            Profit / Loss
          </span>
          <span className={`text-xl font-display font-bold font-mono tracking-tight ${
            isProfit ? 'text-emerald-400' : 'text-rose-400'
          }`}>
            {isProfit ? '+' : ''}{trade.pnlUsdt.toFixed(2)} USDT
          </span>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-gray-500 uppercase block tracking-wider">
            Returns %
          </span>
          <div className="flex items-center justify-end gap-1">
            {isProfit ? (
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            ) : (
              <TrendingDown className="w-4 h-4 text-rose-400" />
            )}
            <span className={`text-sm font-display font-bold font-mono ${
              isProfit ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {isProfit ? '+' : ''}{trade.pnlPercent.toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* Footer Emotional Tracker & Micro notes preview */}
      <div className="border-t border-white/5 pt-3.5 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-sans" title={`Emotional state: ${trade.emotionalState}`}>
            {getEmotionEmoji(trade.emotionalState)}
          </span>
          <span className="text-[10px] font-mono text-gray-400 max-w-[120px] truncate">
            {trade.emotionalState}
          </span>
        </div>

        <div className="flex items-center gap-1 text-[9px] font-mono text-gray-500">
          <BrainCircuit className="w-3 h-3 text-cyan" />
          <span>Unified Account</span>
        </div>
      </div>
    </motion.div>
  );
}
