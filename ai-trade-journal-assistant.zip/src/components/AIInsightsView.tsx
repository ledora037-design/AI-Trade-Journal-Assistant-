import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { BrainCircuit, Sparkles, TrendingUp, AlertTriangle, ShieldCheck, CheckCircle2, Award, Zap } from 'lucide-react';
import { Trade } from '../types';
import { calculatePnL, groupByEmotion } from '../utils/calculations';

interface AIInsightsViewProps {
  trades: Trade[];
}

export default function AIInsightsView({ trades }: AIInsightsViewProps) {
  // Aggregate Insights calculation
  const insights = useMemo(() => {
    if (trades.length === 0) return null;

    const totalTradesCount = trades.length;
    const wins = trades.filter(t => t.pnlUsdt > 0);
    const losses = trades.filter(t => t.pnlUsdt < 0);
    const winRate = parseFloat(((wins.length / totalTradesCount) * 100).toFixed(1));

    // Determine highest frequency emotional state
    const emotionCounts: { [key: string]: number } = {};
    trades.forEach(t => {
      emotionCounts[t.emotionalState] = (emotionCounts[t.emotionalState] || 0) + 1;
    });
    
    let dominantEmotion = 'Calm';
    let maxCount = 0;
    Object.keys(emotionCounts).forEach(em => {
      if (emotionCounts[em] > maxCount) {
        maxCount = emotionCounts[em];
        dominantEmotion = em;
      }
    });

    // Check leverage metrics
    const highLeverageTrades = trades.filter(t => t.leverage >= 20);
    const highLeverageWinrate = highLeverageTrades.length > 0
      ? (highLeverageTrades.filter(t => t.pnlUsdt > 0).length / highLeverageTrades.length) * 100
      : 0;

    const lowLeverageTrades = trades.filter(t => t.leverage < 20);
    const lowLeverageWinrate = lowLeverageTrades.length > 0
      ? (lowLeverageTrades.filter(t => t.pnlUsdt > 0).length / lowLeverageTrades.length) * 100
      : 0;

    // Analyze most profitable pair
    const coinPnlMap: { [key: string]: number } = {};
    trades.forEach(t => {
      coinPnlMap[t.coinName] = (coinPnlMap[t.coinName] || 0) + t.pnlUsdt;
    });

    let bestCoin = 'N/A';
    let bestCoinPnl = -999999;
    let worstCoin = 'N/A';
    let worstCoinPnl = 999999;

    Object.keys(coinPnlMap).forEach(coin => {
      const pnl = coinPnlMap[coin];
      if (pnl > bestCoinPnl) {
        bestCoinPnl = pnl;
        bestCoin = coin;
      }
      if (pnl < worstCoinPnl) {
        worstCoinPnl = pnl;
        worstCoin = coin;
      }
    });

    // Generate dynamic strengths, weaknesses, guidelines
    const strengths: string[] = [];
    const weaknesses: string[] = [];
    const directSuggestions: string[] = [];

    // Evaluate leverages
    if (lowLeverageWinrate > highLeverageWinrate && highLeverageTrades.length > 0) {
      strengths.push("Low-Leverage Precision: Your performance metrics with modest leverage (< 20x) are significantly stronger than high-leverage gambles.");
      weaknesses.push("Leverage Decay: High-leverage entries (>= 20x) are causing rapid stop-outs due to market noise, dragging down your net win-rate.");
      directSuggestions.push("Force a strict ceiling rule: Lock your account leverage at 10x-15x on altcoins for the next 20 trades.");
    } else {
      strengths.push("Consistently high tactical control across major leverage segments.");
    }

    // Evaluate emotions
    const emotionalStats = groupByEmotion(trades);
    const calmStats = emotionalStats.find(s => s.emotion === 'Calm');
    const fomoStats = emotionalStats.find(s => s.emotion === 'FOMO');
    const revengeStats = emotionalStats.find(s => s.emotion === 'Revenge Trading');

    if (calmStats && calmStats.avgPnl > 0) {
      strengths.push(`Composure Quotient: Your Calm trades yield an average return of Class-A $${calmStats.avgPnl.toFixed(2)} USDT.`);
    }

    if (fomoStats && fomoStats.count > 0 && fomoStats.avgPnl < 0) {
      weaknesses.push(`Hype Susceptibility: Trades opened during FOMO conditions represent your highest drag, averaging a loss of $${Math.abs(fomoStats.avgPnl).toFixed(2)} USDT key drawdown.`);
      directSuggestions.push("Implement a 30-minute cooling buffer: If a coin pumps > 5% on 5M timeframe, do not touch. Wait for key daily re-tests.");
    }

    if (revengeStats && revengeStats.count > 0 && revengeStats.avgPnl < 0) {
      weaknesses.push(`Revenge Vulnerability: Logging losses often triggers an urge for immediate entries, resulting in a series of compounding liquidations.`);
      directSuggestions.push("Trigger active blockades: After any consecutive losses, disconnect from the terminal/orderbook for a minimum of 4 hours.");
    }

    // General safeguards fallback
    if (strengths.length < 2) {
      strengths.push("Coin selection: Strong focus on high-liquidity indexes (BTC/ETH) where order depth reduces slippage risks.");
    }
    if (weaknesses.length < 2) {
      weaknesses.push("Position scaling: High fluctuations in margin sizing indicates a lack of consistent risk management units.");
      directSuggestions.push("Size your trades strictly based on account percentage (e.g., standard 1% or 2% portfolio risk per trade stop).");
    }

    return {
      totalTradesCount,
      winRate,
      bestCoin,
      bestCoinPnl,
      worstCoin,
      worstCoinPnl,
      dominantEmotion,
      strengths,
      weaknesses,
      directSuggestions,
      highLeverageTradesCount: highLeverageTrades.length
    };
  }, [trades]);

  if (!insights) {
    return (
      <div className="glass-card rounded-2xl p-8 border border-white/5 flex flex-col items-center justify-center min-h-[380px] text-center max-w-4xl mx-auto">
        <BrainCircuit className="w-12 h-12 text-gray-600 mb-4" />
        <h3 className="font-display font-medium text-gray-400 text-sm mb-1">
          Trading Psychology Assessment Processing...
        </h3>
        <p className="text-xs text-gray-500 max-w-sm leading-relaxed mb-6">
          To build a generalized coaching pattern report, we require historical records. Log at least 1 trade in the Journal or restore demo trades to generate psychological diagnostics.
        </p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      {/* Executive coaching heading */}
      <div className="flex items-center gap-3">
        <div className="bg-cyan/10 p-2.5 rounded-xl text-cyan">
          <BrainCircuit className="w-5 h-5 leading-none" />
        </div>
        <div>
          <h2 className="font-display font-bold text-lg text-white">Advanced Cognitive Analytics</h2>
          <p className="text-xs text-gray-400">Trading psychology evaluations and automated structural audits</p>
        </div>
      </div>

      {/* Main Insights Bento Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* State of Mind Widget */}
        <div className="glass-card rounded-2xl p-5 border border-white/5 flex flex-col justify-between h-48">
          <div>
            <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Dominant Emotion</span>
            <span className="text-xs text-gray-450 text-cyan font-semibold block mt-1.5 uppercase tracking-wide">
              🧠 Overwhelming Composure
            </span>
          </div>
          <div>
            <h4 className="text-2xl font-display font-bold text-white mt-1">
              {insights.dominantEmotion === 'Calm' && '🧘 Calm State'}
              {insights.dominantEmotion === 'Confident' && '⚡ Confident'}
              {insights.dominantEmotion === 'FOMO' && '🔥 FOMO chasing'}
              {insights.dominantEmotion === 'Greedy' && '🤑 Greedy Sizing'}
              {insights.dominantEmotion === 'Fearful' && '😰 Fearful exit'}
              {insights.dominantEmotion === 'Revenge Trading' && '🤬 Revenge plays'}
            </h4>
            <p className="text-[10px] text-gray-500 leading-normal mt-1 leading-relaxed">
              Most of your trades are initiated under this neural posture. Composure directly dictates order fill ratios.
            </p>
          </div>
        </div>

        {/* Highest efficiency symbol */}
        <div className="glass-card rounded-2xl p-5 border border-emerald-500/10 bg-emerald-500/5 flex flex-col justify-between h-48">
          <div>
            <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider block">Top Performing Pair</span>
            <span className="text-xs text-emerald-400 font-semibold block mt-1.5 uppercase tracking-wide">
              🏆 Capital Generator
            </span>
          </div>
          <div>
            <h4 className="text-2xl font-display font-bold text-white mt-1 font-mono uppercase">
              {insights.bestCoin}/USDT
            </h4>
            <p className="text-[10px] text-emerald-500/80 leading-normal mt-1 leading-relaxed">
              You returned a combined net of <strong className="font-bold">+${insights.bestCoinPnl.toFixed(2)} USDT</strong> on this contract structure alone. Double down on this setup.
            </p>
          </div>
        </div>

        {/* Highest leakage symbol */}
        <div className="glass-card rounded-2xl p-5 border border-rose-500/10 bg-rose-500/5 flex flex-col justify-between h-48">
          <div>
            <span className="text-[10px] font-mono text-rose-450 uppercase tracking-wider block text-rose-400">Max Portfolio Drain</span>
            <span className="text-xs text-rose-400 font-semibold block mt-1.5 uppercase tracking-wide">
              ⚠️ Capital Leaks
            </span>
          </div>
          <div>
            <h4 className="text-2xl font-display font-bold text-white mt-1 font-mono uppercase">
              {insights.worstCoin && insights.worstCoin !== 'N/A' ? `${insights.worstCoin}/USDT` : 'None'}
            </h4>
            <p className="text-[10px] text-rose-400/80 leading-normal mt-1 leading-relaxed">
              This asset generated your largest drawdowns. Filter out listings displaying poor liquidity or high-speed slippage wicks.
            </p>
          </div>
        </div>
      </div>

      {/* Strengths & Weaknesses 2-Column Deck */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Technical Strengths */}
        <div className="glass-card rounded-2xl p-6 border border-emerald-500/10">
          <div className="flex items-center gap-2 mb-4 border-b border-emerald-500/10 pb-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-display font-semibold text-emerald-400 text-sm">Identified Edge Strengths</h3>
          </div>
          <ul className="space-y-4">
            {insights.strengths.map((str, i) => (
              <li key={`str-${i}`} className="flex gap-3">
                <div className="w-5 h-5 rounded-full bg-emerald-500/10 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                </div>
                <p className="text-xs text-gray-300 leading-relaxed font-light">{str}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Behavioral Weaknesses */}
        <div className="glass-card rounded-2xl p-6 border border-rose-500/10">
          <div className="flex items-center gap-2 mb-4 border-b border-rose-500/10 pb-3">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            <h3 className="font-display font-semibold text-rose-400 text-sm">Behavioral Performance Flags</h3>
          </div>
          <ul className="space-y-4">
            {insights.weaknesses.map((weak, i) => (
              <li key={`weak-${i}`} className="flex gap-3">
                <div className="w-5 h-5 rounded-full bg-rose-500/10 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-[10px] text-rose-400">⚠️</span>
                </div>
                <p className="text-xs text-gray-300 leading-relaxed font-light">{weak}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Action Directive suggestions */}
      <div className="glass-card rounded-2xl p-6 border border-purple/30 bg-gradient-to-r from-purple/10 to-[#12121400]">
        <div className="flex items-center gap-2.5 mb-4 border-b border-purple/20 pb-3">
          <Zap className="w-5 h-5 text-purple" />
          <h3 className="font-display font-semibold text-purple text-sm">Directives for Next Trade Plays</h3>
        </div>
        <div className="space-y-4">
          {insights.directSuggestions.map((sug, i) => (
            <div key={`sug-${i}`} className="flex gap-3 items-center">
              <span className="text-xs font-mono font-bold text-purple shrink-0 select-none">#{i + 1}</span>
              <p className="text-xs text-gray-300 leading-relaxed font-sans">{sug}</p>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
